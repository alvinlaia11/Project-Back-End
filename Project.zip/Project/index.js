import express from 'express';
import { fileURLToPath } from 'url';
import { dirname } from 'path';


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const hostname = '127.0.0.1';
const port = 8080;

app.use(express.static('public')); //access from public

app.get('(/)', (req, res) => {
    res.sendFile(__dirname + '/public/Product.html');
});

app.get('/logo', (req, res) => {
    res.sendFile(__dirname + '/public/assets/img/Logo.png');
});

app.get('/Login', (req, res) => {
    res.sendFile(__dirname + '/public/Login.html');
});

app.get('/Top Up FF', (req, res) => {
    res.sendFile(__dirname + 'public/Top Up Produt/Top Up FF.html');
});

app.get('/Top Up ML', (req, res) => {
    res.sendFile(__dirname + 'public/Top Up Product/Top Up ML.html');
});

// app.get('/about', (req, res) => {
//     res.sendFile(__dirname + '/public/about.html');
// });
// app.get('/product/:nama', (req, res) => {
//     const nama = req.params.nama; //parameter name
//     res.send(`Product Name : ${nama}`)
// });


app.get('*/:nama', (req, res) => {
    const nama = req.params.nama;
    res.status(404).send(`Direktori ${nama} Tidak Tersedia`);
})
app.listen(port, () => {
    console.log(`Server Running At ${hostname}:${port}`);
});